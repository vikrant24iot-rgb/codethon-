const apiKey = "SUzuxN8lbftXuEjjFsEj5Vhec46MjOhjeTYREUNA";  
const newsList = document.getElementById("news-list");


async function loadCyberNews() {
  const url = `https://api.thenewsapi.com/v1/news/all?api_token=${apiKey}&search=cybersecurity,cybercrime&language=en`;

  try {
    //fetch response
    const response = await fetch(url);
    const data = await response.json();

    //make the list empty
    newsList.innerHTML = ""; 

    //append to list for each article
    data.data.forEach(article => {
      const li = document.createElement("li");

      const a = document.createElement("a");
      a.href = article.url;        // link to original article
      a.textContent = article.title; // show headline
      a.target = "_blank";          // open in new tab

      li.appendChild(a);
      newsList.appendChild(li);
    });

  } catch (err) {
    console.error("Error loading news:", err);
    newsList.innerHTML = "<li>Failed to load news.</li>";
  }
}

loadCyberNews();